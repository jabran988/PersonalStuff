console.log('GitLab MR calculator trigger PoC.');
